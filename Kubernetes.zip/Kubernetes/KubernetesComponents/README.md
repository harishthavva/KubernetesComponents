# KubernetesComponents

**For Deployment Component :- **

kubectl create deployment name --image=image-name [options..]

**If you write all your configuration in Yaml file then run this command** :- 

kubectl apply -f yamlFile
